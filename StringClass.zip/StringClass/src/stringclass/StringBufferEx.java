package stringclass;

public class StringBufferEx {

	public static void main(String[] args) {
		
		StringBuffer s1 = new StringBuffer("Buddy");
		
		s1.append(" is my friend");
		
		System.out.println(s1);

	}

}
