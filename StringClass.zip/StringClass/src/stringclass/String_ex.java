package stringclass;

import java.util.Scanner;

public class String_ex {

	private static Scanner str1;
	private static Scanner str2;
	private static Scanner str3;

	public static void main(String[] args) {
		
		System.out.println("Enter s1");
		str1 = new Scanner(System.in);
		String s1 = str1.next();
				
		System.out.println("Enter s2");
		str2 = new Scanner(System.in);
		String s2 = str2.next();
				
		System.out.println("Enter s3");
		str3 = new Scanner(System.in);
		String s3 = str3.nextLine();
		
		Integer s4 = 10;
		
		if(s1.equals(s2)) {
			System.out.println("both strings are same");
		}
		else {
			System.out.println("both strings are different");
		}
		
		if(s1.equalsIgnoreCase(s2)) {
			System.out.println("both strings are same");
		}
		
		System.out.println(s1.toLowerCase());
		System.out.println(s2.toUpperCase());
		
		System.out.println(s2.concat(s3));
		
		System.out.println(s3.endsWith("t"));
		
		System.out.println(s3.trim());
		
		System.out.println(s1.charAt(3));
		
		System.out.println(s3.charAt(6));
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		
		System.out.println(s1.indexOf(5));
		
		System.out.println(s2.isEmpty());
		
		System.out.println(s3.intern());
		
		System.out.println(s1.lastIndexOf(s1));
		
		System.out.println(s1.length());
		System.out.println(s3.length());
		
		System.out.println(s1.replace('N', 'n'));
		
		System.out.println(s3.startsWith("is"));

		System.out.println(s4.toString());
		
		System.out.println(s1.replaceAll(s1,"AJUDNIH"));
	}

}
