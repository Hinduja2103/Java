package stringclass;

public class String_ex2 {

	public static void main(String[] args) {
		
		String s1 = "Buddy";
		
		System.out.println(s1.concat(" is my friend"));
		
		System.out.println(s1);

	}

}
