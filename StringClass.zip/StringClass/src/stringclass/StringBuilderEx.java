package stringclass;

public class StringBuilderEx {

	public static void main(String[] args) {
		
		StringBuilder s1 = new StringBuilder("TajMahal");
		
		System.out.println(s1.capacity());
		
		System.out.println(s1.lastIndexOf("TajMahal"));
		
		System.out.println(s1.substring(3, 5));
		
		System.out.println(s1.append(" is one among the 7 wonders of the World"));
		
		System.out.println(s1.insert(3, ' '));
		
		System.out.println(s1.reverse());

	}

}
