package demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BufferedEvenOrOdd {

	public static void main(String[] args) throws IOException {
		
		InputStreamReader in= new InputStreamReader(System.in);
		BufferedReader bf = new BufferedReader(in);
		System.out.println("Enter your num :");
		int n = bf.read();
		
		if(n%2==0) {
			System.out.println("It is a even number");
		}
		else {
			System.out.println("it is a odd number");
		}
	}
}