package demo;

import java.io.*;

public class BufferedReaderExample3 {

	public static void main(String[] args)throws Exception {
		
		InputStreamReader r = new InputStreamReader(System.in);
		
		BufferedReader br = new BufferedReader(r);
		
		String name = "";
		
		while(!name.contentEquals("stop"))
			
		{
			System.out.println("enter data : ");
			
			name = br.readLine();
			
			System.out.println("data is : "+name);
		}
		br.close();
		r.close();
	}

}

