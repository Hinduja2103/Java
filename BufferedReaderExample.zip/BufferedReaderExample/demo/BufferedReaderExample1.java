package demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BufferedReaderExample1 {
	
	public static void main(String[] args) throws IOException {
		
		//System.out.println("Enter any string: ");
		/*
		 * Scanner s = new Scanner(System.in);
		 * 
		 * String a=s.next();
		 * 
		 * System.out.println(a);
		 */
		
		InputStreamReader in= new InputStreamReader(System.in);
		
		BufferedReader bf = new BufferedReader(in);
		
		System.out.println("Enter your Input :");
		String str=bf.readLine();
		System.out.println(str);
		int i= Integer.valueOf(str);
		
		System.out.println(i);
		
		
	}

}
