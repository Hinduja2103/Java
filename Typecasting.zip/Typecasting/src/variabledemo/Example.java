package variabledemo;

public class Example {
	
	static int a = 10;
	static int c = 10;
	
	public static void main(String args[]) {
		
		int b = 20;
		display();
		System.out.println(b);
		System.out.println(a);
		System.out.println(c++);
		System.out.println(c);
	}
	
	public static void display() {
		int d = 20;
		System.out.println(d);
	}

}
