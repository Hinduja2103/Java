package variabledemo;

public class Widening {

	public static void main(String[] args) {
		
		int a = 10;
		int b = 20;
		float c;
		c = (float) (a+b);
		
		System.out.println(c);

	}

}
