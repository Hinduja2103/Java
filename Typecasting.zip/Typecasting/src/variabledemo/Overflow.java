package variabledemo;

public class Overflow {

	public static void main(String[] args) {
		
		byte b = (byte) 500;
		
		System.out.println(b);

	}

}
