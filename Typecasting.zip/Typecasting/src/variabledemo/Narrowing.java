package variabledemo;

public class Narrowing {

	public static void main(String[] args) {
		
		int a = 10;
		float b = 10.5f;
		int c;
		
		c = (int) (a+b);
		
		System.out.println(a+b);
		System.out.println(c);

	}

}
