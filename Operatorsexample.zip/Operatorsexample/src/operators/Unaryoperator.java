package operators;

public class Unaryoperator {

	public static void main(String[] args) {
		
		int a = 10;
		int b = a++;
		
		System.out.println(a);
		System.out.println(b);
		
		int c = ++a;
		int d = --a;
		
		System.out.println(c);
		System.out.println(d);

	}

}
