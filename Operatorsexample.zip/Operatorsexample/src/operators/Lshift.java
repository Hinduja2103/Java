package operators;

public class Lshift {

	public static void main(String[] args) {
		
		int a = 20;
		int b = 50;
		
		System.out.println(++a<<3);
		System.out.println(b--<<5);
		System.out.println(a);
		System.out.println(b);
	}

}
