package demo;

public class TryCatchEx {

	@SuppressWarnings("null")
	public static void main(String[] args) {
		int a=10;
		int b=0;
		int ar[]= {10,30,20};
		String s=null;
		
		try {
			s.toUpperCase();
			System.out.println(ar[3]);
			@SuppressWarnings("unused")
			int c=a/b;
			System.out.println("Your account have "+ a*b +" rs balance");
		}
		
		catch(NullPointerException ae) {
			System.out.println("You are trying to work on null value");
		}
		
		catch(ArithmeticException ae) {
			System.out.println("Please add money into your account to withdraw");
		}
		
		catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println("Arey index value u r acceessing is not there");
		}
		
		finally {
			System.out.println("thanks for using atm");
		}
	}
}

