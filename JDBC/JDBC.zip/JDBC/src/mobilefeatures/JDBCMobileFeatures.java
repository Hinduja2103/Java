package mobilefeatures;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCMobileFeatures {
	
	public static void main(String args[]) throws ClassNotFoundException, SQLException {
		//load the driver in to the class
    	Class.forName("org.postgresql.Driver");

		//create connection using driver manager
    	Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5433/postgres", "postgres", "postgres");
    	
    	System.out.println("Connection created Successfully" + connection);
	
    	Statement st=connection.createStatement();
    	String SQL ="select * from mobile_features";
    	ResultSet rs=st.executeQuery(SQL);
    	
    	while(rs.next()) {
    		System.out.println(rs.getString(2));
    	}
    	
    	rs.close();
    	st.close();
    	connection.close();
    	/*
		 * String SQL =
		 * "INSERT INTO  prime.non_prime_asset_details (subject_id,np_asset_id," +
		 * "title,description,sub_category,path_url,asset_type_id,asset_type_title,source_name,source_type,"
		 * + "created_at,updated_at,created_by,updated_by)" + " " +
		 * "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)"; PreparedStatement statement =
		 * connection.prepareStatement(SQL); //Read JSON file
		 */	
     }
 
}