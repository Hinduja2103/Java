package mobilefeatures;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MobilePrice {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Class.forName("org.postgresql.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5433/postgres", "postgres", "postgres");
		
		Statement st = con.createStatement();
		
		String SQL = "select * from mobile_features";
		
		ResultSet rs = st.executeQuery(SQL);
		
		while (rs.next()) {
    		System.out.println(rs.getString(3));
    	}
    	
    	rs.close();
    	st.close();
    	con.close();
	}

}
