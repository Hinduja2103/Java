package employeedetails;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EmployeeDetailsPreparedStatementBatch {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException, NumberFormatException {

		Class.forName("org.postgresql.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5433/postgres","postgres","postgres");
		
		String SQL = "insert into employee_details(emp_name, mobile_no, mail_id, emp_role, salary) values(?,?,?,?,?)";
		
		PreparedStatement pst = con.prepareStatement(SQL);
		
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader bf = new BufferedReader(in);	
		while(true) {
			
			System.out.println("Enter emp_name : ");
			String name = bf.readLine();
			
			System.out.println("Enter mobile_no : ");
			String num = bf.readLine();
			
			System.out.println("Enter mail_id : ");
			String mailid = bf.readLine();
			
			System.out.println("Enter emp_role : ");
			String role = bf.readLine();
			
			System.out.println("Enter salary : ");
			String s = bf.readLine();
			int salary = Integer.parseInt(s);
			
			pst.setString(1, name);
			pst.setString(2, num);
			pst.setString(3, mailid);
			pst.setString(4, role);
			pst.setLong(5, salary);
			pst.addBatch();
			
			System.out.println("Wnat to more records y/n : ");
			String ans = bf.readLine();
			
			if(ans.equals("n")) {
				break;
			}
		}
		pst.executeBatch();
		
		System.out.println("Records Succesfully Inserted");
		pst.close();
		con.close();
	}

}