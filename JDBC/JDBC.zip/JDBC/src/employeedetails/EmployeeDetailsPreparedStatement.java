package employeedetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EmployeeDetailsPreparedStatement {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Class.forName("org.postgresql.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5433/postgres","postgres","postgres");
		
		String SQL = "insert into employee_details(emp_name, mobile_no, mail_id, emp_role, salary) values('Manoj', '0123456789', 'manoj@gmail.com', 'Project Engineer', '120000')";
		
		PreparedStatement pst = con.prepareStatement(SQL);
		
		int affectedrows = pst.executeUpdate();
		
		System.out.println(affectedrows+" row(s) affected");
		
		pst.close();
		con.close();
	
	}

}
