package books;

public interface IFiction {

	default void fiction() {
		System.out.println("The Twiligth Series");
	}
	
	static void sciencefiction() {
		System.out.println("The Calculating Stars");
	}
	
	void novel();
}
