package books;

public abstract class NonFiction implements IFiction{

	void nonfiction() {
		System.out.println("The Chronicles of Narnia");
	}
}
