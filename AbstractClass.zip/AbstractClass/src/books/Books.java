package books;

public class Books extends NonFiction {

	public static void main(String[] args) {
		Books b = new Books();
		b.fiction();
		b.nonfiction();
		b.novel();
		IFiction.sciencefiction();
	}

	@Override
	public void novel() {
		System.out.println("Half Girlfriend");
	}

}
