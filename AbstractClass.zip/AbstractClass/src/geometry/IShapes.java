package geometry;

public interface IShapes {

	default void rectangle() {
		System.out.println("A Classroom Board is a Rectangle");
	}
	
	static void square() {
		System.out.println("A Chess Board is a Square");
	}
	
	abstract void sphere();
}
