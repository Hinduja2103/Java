package geometry;

public class Geometry extends Shapes{

	public static void main(String[] args) {
		
		System.out.println("Different types of Shapes and its Examples");
		
		Geometry g = new Geometry();
		
		g.circle();
		g.rectangle();
		IShapes.square();
		g.sphere();
		
	}
	
	@Override
	public void sphere() {
		
		System.out.println("A Ball is sphere");
	}

}
