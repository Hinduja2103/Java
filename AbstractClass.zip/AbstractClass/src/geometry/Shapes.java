package geometry;

public abstract class Shapes implements IShapes {

	void circle() {
		
		System.out.println("A Ring is a Circle");
	}
	
}
