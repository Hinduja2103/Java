package demo;

public class BluePrint extends Develop {

	public static void main(String[] args) {
		
		BluePrint bp = new BluePrint();
		
		bp.understandconcept();
		bp.preparedraft();
		bp.builddesign();
		bp.inspection();
		
	}
	
	@Override
	public void understandconcept() {
	
		System.out.println("Understand the Concept");
	}

	@Override
	public void preparedraft() {
		
		System.out.println("Prepare a Draft");
	}

	@Override
	public void builddesign() {
		
		System.out.println("Build a Design");
	}

}
