package demo;

public interface IDesign {

	void understandconcept();
	
	void preparedraft();
	
	void builddesign();

}

