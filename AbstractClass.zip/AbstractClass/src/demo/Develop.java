package demo;

public abstract class Develop implements IDesign {

	void inspection() {
		
		System.out.println("Hello inspection is going on!");
	}
	
}
