package newspapers;

public class Newspaper {
	
	public Newspaper() {
		
		System.out.println("Lets see what is the hot topic in news today");
		this.name = "Newspaper";
	}
	
	String name;
	int copies;
	Float price;
	String type;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCopies() {
		return copies;
	}
	public void setCopies(int copies) {
		this.copies = copies;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}
