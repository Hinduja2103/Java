package newspapers;

public class DeccanHerald extends Newspaper {
	
	public DeccanHerald() {
		
		super.name = "Deccan Herald";
		System.out.println("Hey there! its Deccan Herald here");
	}

	public static void main(String[] args) {
		
		DeccanHerald d = new DeccanHerald();
		d.setType("Black & White");
		System.out.println("Type : "+d.getType());
	}

}
