package newspapers;

public class TimesOfIndia extends Newspaper {

	public TimesOfIndia() {
		
		System.out.println("I am the largest ciculated newspaper in India");
	}
	
	public static void main(String[] args) {
		
		Newspaper n = new TimesOfIndia();
		n.setName("The Times of India");
		n.setPrice(6.00f);
		n.setCopies(100000);
		n.setType("Color");
		
		System.out.println("Name : "+n.getName());
		System.out.println("Price : "+n.getPrice());
		System.out.println("No. of copies sold per day : "+n.getCopies());
		System.out.println("Type : "+n.getType());

	}

}
