package animal;

public class Herbivorous extends Animals {
	
	public Herbivorous() {
		
		System.out.println("Hi i am a Herbivorous animal");
	}

	public static void main(String[] args) {
		
		Animals a = new Herbivorous();
		
		a.setName("Goat");
		a.setFood("Grass");
		a.setMoving_type("Run or Walk");
		a.setType("Mammal");
		
		System.out.println("Name : "+a.getName());
		System.out.println("Food : "+a.getFood());
		System.out.println("Moves by :"+a.getMoving_type());
		System.out.println("Type : "+a.getType());
	}

}
