package animal;

public class Carnivorous extends Animals{
	
	public Carnivorous() {
		
		System.out.println("Hi i am a Carnivorous animal");
	}
	public static void main(String[] args) {
		
		Animals a = new Carnivorous();
		
		a.setName("Snake");
		a.setFood("Meat");
		a.setMoving_type("Crawl");
		a.setType("Reptile");
		
		System.out.println("Name : "+a.getName());
		System.out.println("Food : "+a.getFood());
		System.out.println("Moves by :"+a.getMoving_type());
		System.out.println("Type : "+a.getType());
	}

}
