package animal;

public class Animals {
	
	public Animals() {
		System.out.println("Welcome to Jungle Safari");
	}
	
	String name;
	String moving_type;
	String food;
	String type;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the moving_type
	 */
	public String getMoving_type() {
		return moving_type;
	}
	/**
	 * @param moving_type the moving_type to set
	 */
	public void setMoving_type(String moving_type) {
		this.moving_type = moving_type;
	}
	/**
	 * @return the food
	 */
	public String getFood() {
		return food;
	}
	/**
	 * @param food the food to set
	 */
	public void setFood(String food) {
		this.food = food;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
}
