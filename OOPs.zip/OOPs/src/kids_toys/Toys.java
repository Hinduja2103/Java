package kids_toys;

public class Toys {
	
	public Toys() {
		System.out.println("Hey there! Welcome to Kids world");
		this.type = "Toys";
	}
	
	String name;
	float price;
	String type;
	int pieces;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getPieces() {
		return pieces;
	}
	public void setPieces(int pieces) {
		this.pieces = pieces;
	}
	
	
}
