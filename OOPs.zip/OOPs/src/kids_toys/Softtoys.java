package kids_toys;

public class Softtoys extends Toys {
	
	public Softtoys() {
		super();
		System.out.println("Hello i am Kungfu Panda");
	}
	public static void main(String[] args) {
		
		Toys t = new Softtoys();
		
		t.setName("Panda");
		t.setPrice(50.0f);
		t.setType("Soft");
		t.setPieces(1);
		
		System.out.println("Name : "+t.getName());
		System.out.println("Price : "+t.getPrice());
		System.out.println("Type : "+t.getType());
		System.out.println("No. of Pieces : "+t.getPieces());

	}

}
