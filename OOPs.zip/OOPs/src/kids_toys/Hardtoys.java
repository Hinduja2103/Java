package kids_toys;

public class Hardtoys extends Toys {
	
	public Hardtoys() {
		
		super.type = "Hard Toys";
		System.out.println("Hello i am Building Blocks");
	}

	public static void main(String[] args) {
		
		Hardtoys h = new Hardtoys();
		h.setPieces(50);
		System.out.println("Pieces : "+h.getPieces());

	}

}
