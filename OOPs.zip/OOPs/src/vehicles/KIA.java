package vehicles;

public class KIA extends Vehicle {
	
	public KIA() {
		
		super();
		System.out.println("Hello it's KIA Motors");
	}

	public static void main(String[] args) {
		
		Vehicle v = new KIA();
		
		v.setModel("X");
		v.setName("KIA");
		v.setPrice(2500000.00f);
		v.setWheels(4);
		
		System.out.println("Name : "+v.getName());
		System.out.println("Model : "+v.getModel());
		System.out.println("Price : "+v.getPrice());
		System.out.println("Wheels : "+v.getWheels());

	}

}
