package vehicles;

public class Vehicle {
	
	Vehicle(){
		System.out.println("Hello am super class constructor");
		this.model="Vehicle";
	}
	
	int wheels;
	String name;
	String model;
	float price;
	
	@SuppressWarnings("unused")
	private void hiding() {
		System.out.println("hello i am hidden, you cant see me");
	}
	/**
	 * @return the wheels
	 */
	public int getWheels() {
		return wheels;
	}
	/**
	 * @param wheels the wheels to set
	 */
	public void setWheels(int wheels) {
		this.wheels = wheels;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}
	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}
	/**
	 * @return the price
	 */
	public float getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(float price) {
		this.price = price;
		
	}
	
	

}
