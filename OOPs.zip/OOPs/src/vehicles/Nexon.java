package vehicles;

public class Nexon extends Vehicle {
	
	public Nexon() {
		// TODO Auto-generated constructor stub
	//super();
		super.model="Nexon";
		System.out.println("Hello am nexon constructor!");
	}
	
	public static void main(String args[]) {
		
		Nexon obj = new Nexon();
		System.out.println("Model" + obj.getModel());
		obj.getModel();
	
	}


}
