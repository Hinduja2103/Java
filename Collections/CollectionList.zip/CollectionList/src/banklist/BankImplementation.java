package banklist;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class BankImplementation {
	public static void main(String args[]) throws IOException {
		
		List<Bank>  banksList= new ArrayList<>();
		
		System.out.println("Enter range :");
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader bf= new BufferedReader(in);
		Integer n= Integer.valueOf(bf.readLine());
		System.out.println(n);
		
		for(int i=1;i<=n;i++) {
			Bank bankObject= new Bank();
			System.out.println("Enter your bank"+ (i) +" name");
			String bname=	bf.readLine();
			System.out.println("Enter your bank " + (i) + "IFSCCODE");
			String ifsc=	bf.readLine();
			System.out.println("Enter your bank " + (i) + "main branch name");
			String mainBranch=bf.readLine();
			
			System.out.println("How many locations is your bank located");
			Integer lcount=Integer.valueOf(bf.readLine());
			List<String>  locations= new ArrayList<>();
			for(int j=1;j<=lcount;j++) {
				System.out.println("Enter your "+ i +"bank " + j +"Location Name");
				locations.add(bf.readLine());		
			}
		
			bankObject.setId(i);
			bankObject.setName(bname);
			bankObject.setIfscCode(ifsc); 
			bankObject.setMainbranch(mainBranch);
			bankObject.setLocations(locations);
			banksList.add(bankObject);
		}
		
		for(Bank blist:banksList) {
			System.out.println("Bank Name      :"+blist.getName());
			System.out.println("Bank IFSC CODE :"+blist.getIfscCode());
			System.out.println("Main Branch    :"+blist.getMainbranch());
			System.out.println("Locations of your branch :" + blist.getLocations().toString());
			System.out.println("________________________________________________________________________");
		}
		
	}

}