package employeelist;

import java.util.ArrayList;
import java.util.List;

public class EmployeeListMainClass extends EmployeeList {
	
	static {
		System.err.println("BEASANT TECHNOLOGIES Pvt.Ltd");
		System.out.println("----------------------------------------------------------------------------");
		System.err.println("Employees Details");
	}	

	public static void main(String[] args) {
		
		List<EmployeeList> emplist = new ArrayList<EmployeeList>();
		
		EmployeeList e1 = new EmployeeList();
		e1.setName("Kiran");
		e1.setId(101);
		e1.setAge(30);
		e1.setMail_id("kiran@gmail.com");
		e1.setGender("Male");
		e1.setRole("CEO");
		
		EmployeeList e2 = new EmployeeList();
		e2.setName("Hinduja");
		e2.setId(202);
		e2.setAge(24);
		e2.setMail_id("hinduja@gamil.com");
		e2.setGender("Female");
		e2.setRole("Manager");
		
		EmployeeList e3 = new EmployeeList();
		e3.setName("Srrikanth");
		e3.setId(303);
		e3.setAge(23);
		e3.setMail_id("srikanth@gmail.com");
		e3.setGender("Male");
		e3.setRole("Project Engineer");
		
		emplist.add(e1);
		emplist.add(e2);
		emplist.add(e3);
		
		for(EmployeeList e:emplist) {
			System.out.println(e.getName());
			System.out.println(e.getId());
			System.out.println(e.getAge());
			System.out.println(e.getMail_id());
			System.out.println(e.getGender());
			System.out.println(e.getRole());
			System.out.println(" ");
		}
	}
}
