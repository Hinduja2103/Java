package restrauntlist;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class RestrauntImplementation {

	public static void main(String[] args) throws IOException {

		List<Restraunt> menu = new ArrayList<>();
		
		Restraunt restrauntObject = new Restraunt();
		
		System.out.println("Enter Restraunt Name : ");
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader bf = new BufferedReader(in);
		String name = bf.readLine();
		
		System.out.println("Is A/c Available ? ");
		boolean ac = bf.markSupported();
		
		System.out.println("Enter range for Veg Starters : ");
		Integer n= Integer.valueOf(bf.readLine());
		List<String> veg_starters = new ArrayList<>();
		for(int i=1; i<=n; i++) {
			System.out.println("Enter Veg Starter "+i);
			veg_starters.add(bf.readLine());			
		}
		
		System.out.println("Enter range for Non-Veg Starters : ");
		Integer n1= Integer.valueOf(bf.readLine());
		List<String> nonveg_starters = new ArrayList<>();
		for(int i=1; i<=n1; i++) {
			System.out.println("Enter Non-Veg Starter "+i);
			nonveg_starters.add(bf.readLine());
		}
		
		System.out.println("Enter range for Veg Maincoarse : ");
		Integer n2= Integer.valueOf(bf.readLine());
		List<String> veg_maincourse = new ArrayList<>();
		for(int i=1; i<=n2; i++) {
			System.out.println("Enter Veg Maincoarse "+i);
			veg_maincourse.add(bf.readLine());
		}
		
		System.out.println("Enter range for Non-Veg Maincoarse : ");
		Integer n3= Integer.valueOf(bf.readLine());
		List<String> nonveg_maincourse = new ArrayList<>();
		for(int i=1; i<=n3; i++) {
			System.out.println("Enter Non-Veg Maincoarse "+i);
			nonveg_maincourse.add(bf.readLine());
		}
		
		System.out.println("Enter range for Deserts : ");
		Integer n4= Integer.valueOf(bf.readLine());
		List<String> deserts = new ArrayList<>();
		for(int i=1; i<=n4; i++) {
			System.out.println("Enter Deserts "+i);
			deserts.add(bf.readLine());
		}
		
		restrauntObject.setName(name);
		restrauntObject.setAc(ac);
		restrauntObject.setVeg_starters(veg_starters);
		restrauntObject.setNonveg_starters(nonveg_starters);
		restrauntObject.setVeg_maincourse(veg_maincourse);
		restrauntObject.setNonveg_maincourse(nonveg_maincourse);
		restrauntObject.setDeserts(deserts);
		menu.add(restrauntObject);
		
		for(Restraunt r : menu) {
			System.out.println("Restraunt Name     : "+r.getName());
			System.out.println("A/c Availabiltiy   : "+r.isAc());
			System.out.println("Veg Straters       : "+r.getVeg_starters());
			System.out.println("Non-Veg Starters   : "+r.getNonveg_starters());
			System.out.println("Veg Maincoarse     : "+r.getVeg_maincourse());
			System.out.println("Non-Veg Maincoarse : "+r.getNonveg_maincourse());
			System.out.println("Deserts            : "+r.getDeserts());
		}
	
	}

}