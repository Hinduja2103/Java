package restrauntlist;

import java.util.List;

public class Restraunt {

	String name;
	boolean ac;
	List<String> veg_starters;
	List<String> nonveg_starters;
	List<String> veg_maincourse;
	List<String> nonveg_maincourse;
	List<String> deserts;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isAc() {
		return ac;
	}
	public void setAc(boolean ac) {
		this.ac = ac;
	}
	public List<String> getVeg_starters() {
		return veg_starters;
	}
	public void setVeg_starters(List<String> veg_starters) {
		this.veg_starters = veg_starters;
	}
	public List<String> getNonveg_starters() {
		return nonveg_starters;
	}
	public void setNonveg_starters(List<String> nonveg_starters) {
		this.nonveg_starters = nonveg_starters;
	}
	public List<String> getVeg_maincourse() {
		return veg_maincourse;
	}
	public void setVeg_maincourse(List<String> veg_maincourse) {
		this.veg_maincourse = veg_maincourse;
	}
	public List<String> getNonveg_maincourse() {
		return nonveg_maincourse;
	}
	public void setNonveg_maincourse(List<String> nonveg_maincourse) {
		this.nonveg_maincourse = nonveg_maincourse;
	}
	public List<String> getDeserts() {
		return deserts;
	}
	public void setDeserts(List<String> deserts) {
		this.deserts = deserts;
	}
	
}
