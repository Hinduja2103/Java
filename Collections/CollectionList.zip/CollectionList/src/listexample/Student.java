package listexample;

import java.util.*;

public class Student {

	static {
		System.err.println("Viswesvaraya Technological University");
		System.out.println("-----------------------------------------------------------------------------");
		System.err.println("Student Details");
	}
	public static void main(String[] args) {
		
		List<String> s1 = new ArrayList<String>(); 
		s1.add(" ");
		s1.add("Hinduja");
		s1.add("101");
		s1.add("ECE");
		s1.add("AIT");
		s1.add(" ");
		
		List<String> s2 = new ArrayList<String>();
		s2.add("Yashaswini");
		s2.add("202");
		s2.add("EIE");
		s2.add("B.R.AIT");
		s2.add(" ");
		
		List<String> s3 = new ArrayList<String>();
		s3.add("Srikanth");
		s3.add("303");
		s3.add("ME");
		s3.add("BIT");
		s3.add(" ");
		
		List<String> s4 = new ArrayList<String>();
		s4.add("Gaurav");
		s4.add("404");
		s4.add("ECE");
		s4.add("AIT");
		s4.add(" ");
		
		List<String> s5 = new ArrayList<String>();
		s5.add("Shrinivas");
		s5.add("505");
		s5.add("ECE");
		s5.add("SIT");
		
		s1.addAll(s2);
		s1.addAll(s3);
		s1.addAll(s4);
		s1.addAll(s5);
		
		for(String i:s1)
			System.out.println(i);
		
		System.out.println("-----------------------------------------------------------------------------");
		
		Set<String> s = new HashSet<String>();
		s.addAll(s1);
		
		for(String j:s)
			System.out.println(j);
		
		System.out.println("Size of a set is : "+s.size());
	}

}
