package listexample;

import java.util.ArrayList;
import java.util.List;

public class Employee {

	static {
		System.err.println("BEASANT TECHNOLOGIES Pvt.Ltd");
		System.out.println("----------------------------------------------------------------------------");
		System.err.println("Employees Details");
	}
	public static void main(String[] args) {
		
		List<String> e1= new ArrayList<String>();
		e1.add(" ");
		e1.add("Kiran");
		e1.add("30");
		e1.add("101");
		e1.add("kiran@gmail.com");
		e1.add("4567890123");
		e1.add("CEO");
		e1.add("Developer");
		e1.add("Male");
		e1.add(" ");
		
		List<String> e2= new ArrayList<String>();
		e2.add("Hinduja");
		e2.add("24");
		e2.add("202");
		e2.add("hinduja@gmail.com");
		e2.add("1234567890");
		e2.add("HR Manager");
		e2.add("Java Developer");
		e2.add("Female");
		e2.add(" ");
		
		List<String> e3= new ArrayList<String>();
		e3.add("Yashaswini");
		e3.add("22");
		e3.add("303");
		e3.add("yashaswini@gmail.com");
		e3.add("2345678901");
		e3.add("Tech Lead");
		e3.add("Web Developer");
		e3.add("Female");
		e3.add(" ");
		
		List<String> e4= new ArrayList<String>();
		e4.add("Srikanth");
		e4.add("23");
		e4.add("404");
		e4.add("srikanth@gmail.com");
		e4.add("3456789012");
		e4.add("Project Engineer");
		e4.add("Test Automation");
		e4.add("Male");
		e4.add(" ");
		
		List<String> e5= new ArrayList<String>();
		e5.add("Gaurav");
		e5.add("21");
		e5.add("505");
		e5.add("gaurav@gmail.com");
		e5.add("5678901234");
		e5.add("Project Engineer");
		e5.add("App Developer");
		e5.add("Male");
		e5.add(" ");
		
		List<String> e6= new ArrayList<String>();
		e6.add("Shrinivas");
		e6.add("21");
		e6.add("606");
		e6.add("shrinivas@gmail.com");
		e6.add("6789012345");
		e6.add("Project Engineer");
		e6.add("Software Developer");
		e6.add("Male");
		
		e1.addAll(e2);
		e1.addAll(e3);
		e1.addAll(e4);
		e1.addAll(e5);
		e1.addAll(e6);

		for(String i:e1) {
			System.out.println(i);
		}
	
	}

}
