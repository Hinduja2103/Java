package demo;

import java.util.List;
import java.util.ArrayList;
import java.util.Collection;

public class ListEx {
	@SuppressWarnings({ "rawtypes", "unused" })
	public static void main(String[] args) {

		Collection c;
	    Object obj;
		
	    /*
		 * // obj. // obj.hashCode(); c.add(obj); c.addAll(c); c.remove(obj);
		 * c.removeAll(c); c.containsAll(c); c.contains(obj); c.clear(); c.size();
		 * c.isEmpty(); c.iterator();
		 */
	    
	    List<Integer> li= new ArrayList<Integer>();
	    li.add(1);
	    li.add(1);
	    li.add(1);
	    li.add(1);
	    li.add(1);
	    li.add(2);
	    li.add(1);
	    li.add(1);
	    li.add(1);
	    li.add(6);
	    li.add(1);
	    li.add(1);
	    li.add(6);
	    li.add(1);
	    li.add(9);
	    li.add(10);

	    for(Integer i:li) {
	    	System.out.println(li.contains(1));
	    }
	    
	}

}
