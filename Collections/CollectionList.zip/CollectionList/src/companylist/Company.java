package companylist;

import java.util.List;

public class Company {
	
	int id;
	String name;
	String reg_no;
	String mail_id;
	boolean iso_certified;
	String mainbranch;
	public String getMainbranch() {
		return mainbranch;
	}
	public void setMainbranch(String mainbranch) {
		this.mainbranch = mainbranch;
	}
	List<String> locations;
	List<String> employees;
	
	public String getReg_no() {
		return reg_no;
	}
	public void setReg_no(String reg_no) {
		this.reg_no = reg_no;
	}
	public boolean isIso_certified() {
		return iso_certified;
	}
	public void setIso_certified(boolean iso_certified) {
		this.iso_certified = iso_certified;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMail_id() {
		return mail_id;
	}
	public void setMail_id(String mail_id) {
		this.mail_id = mail_id;
	}
	public List<String> getBranches() {
		return locations;
	}
	public void setBranches(List<String> locations) {
		this.locations = locations;
	}
	public List<String> getEmployees() {
		return employees;
	}
	public void setEmployees(List<String> employees) {
		this.employees = employees;
	}
}
