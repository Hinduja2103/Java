package companylist;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class CompanyImplementation {

	public static void main(String[] args) throws IOException {
		
		List<Company> companylist = new ArrayList<>();
		
		System.out.println("Enter range :");
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader bf= new BufferedReader(in);
		Integer n= Integer.valueOf(bf.readLine());
		System.out.println(n);
		
		for(int i=1; i<=n; i++) {
			Company companyObject = new Company();
			System.out.println("Enter Company "+i+" name");
			String name = bf.readLine();
			System.out.println("Enter Company "+i+" Registration Number");
			String reg_no = bf.readLine();
			System.out.println("Enter Company "+i+" Mail Id");
			String mail_id = bf.readLine();
			System.out.println("Is Company "+i+" ISO Certified ?");
			boolean iso_certified = bf.markSupported();
			System.out.println("Company "+i+" Main Branch Location");
			String mainbranch = bf.readLine();
			
			System.out.println("How many branches does Company have ?");
			Integer lcount=Integer.valueOf(bf.readLine());
			List<String>  locations= new ArrayList<>();
			for(int j=1;j<=lcount;j++) {
				System.out.println("Enter "+ i +" Company " + j +" Location Name");
				locations.add(bf.readLine());		
			}
			
			System.out.println("How many Employees do work in Company "+i+" ?");
			Integer ecount=Integer.valueOf(bf.readLine());
			List<String>  employees= new ArrayList<>();
			for(int j=1;j<=ecount;j++) {
				System.out.println("Enter "+ i +" Company " + j +" Employee Name");
				employees.add(bf.readLine());		
			}
			
			companyObject.setId(i);
			companyObject.setName(name);
			companyObject.setReg_no(reg_no);
			companyObject.setMail_id(mail_id);
			companyObject.setIso_certified(iso_certified);
			companyObject.setMainbranch(mainbranch);
			companyObject.setBranches(locations);
			companyObject.setEmployees(employees);
			companylist.add(companyObject);
		}
		
		for(Company c : companylist) {
			System.out.println(" ");
			System.out.println("Company Name              : "+c.getName());
			System.out.println("Company Registration No.  : "+c.getReg_no());
			System.out.println("Company Mail Id           : "+c.getMail_id());
			System.out.println("Company ISO Certified     : "+c.isIso_certified());
			System.out.println("Company Main Branch       : "+c.getMainbranch());
			System.out.println("Company Branch Locations  : "+c.getBranches());
			System.out.println("Company Employees Names   : "+c.getEmployees());
			System.out.println("--------------------------------------------------------------------------");
		}
		
	}

}
