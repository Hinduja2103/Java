package mobilemodelMap;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class MobileModelImplementation {

	public static void main(String[] args) throws IOException {

		Map<MobileModel, List<String>> mobilemap = new HashMap<MobileModel, List<String>>();
		
		System.out.println("Enter range :");
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader bf= new BufferedReader(in);
		Integer n= Integer.valueOf(bf.readLine());
		
		for(int i=1; i<=n; i++) {
			MobileModel mmObject = new MobileModel();
			
			System.out.println("Enter Mobile "+i+" name :");
			String mname = bf.readLine();
			
			System.out.println("Enter range for versions of Programming Language :");
			Integer m= Integer.valueOf(bf.readLine());
			List<String>  model = new ArrayList<>();
			for(int j=1; j<=m; j++) {
				System.out.println("Enter "+j+" model of Mobile "+i+" :");
				model.add(bf.readLine());
			}
			
			mmObject.setMname(mname);
			mmObject.setModel(model);
			mobilemap.put(mmObject,(List<String>) model);
		}
		
		for(Entry<MobileModel, List<String>> m : mobilemap.entrySet()) {
			System.out.println(m.getKey().getMname());
			System.out.println(m.getValue());
			System.out.println("-------------------------------------------------------------------------");
		}
	
	}

}