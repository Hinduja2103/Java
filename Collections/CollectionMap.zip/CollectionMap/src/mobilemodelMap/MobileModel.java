package mobilemodelMap;

import java.util.List;

public class MobileModel {

	String mname;
	List<String> model;
	
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public List<String> getModel() {
		return model;
	}
	public void setModel(List<String> model) {
		this.model = model;
	}
}
