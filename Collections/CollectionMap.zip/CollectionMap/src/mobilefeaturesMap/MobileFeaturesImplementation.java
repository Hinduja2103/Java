package mobilefeaturesMap;

import java.io.*;
import java.util.*;
import java.util.Map.Entry;

public class MobileFeaturesImplementation {

	public static void main(String[] args) throws IOException {

		Map<MobileFeatures, List<String>> featuresmap = new HashMap<MobileFeatures, List<String>>();
		
		MobileFeatures mf1 = new MobileFeatures("iPhone XS Max", null);
		List<String> f1 = new ArrayList<String>();
		f1.add("Rs. 1,19,900");
		f1.add("8GB RAM");
		f1.add("128GB ROM");
		f1.add("6.5 inches");
		f1.add("12+12 MP Dual Rear Cameras");
		f1.add("7 MP Front Camera");
		f1.add("3174 mAh Battery");
		
		MobileFeatures mf2 = new MobileFeatures("Vivo F11 Pro", null);
		List<String> f2 = new ArrayList<String>();
		f2.add("Rs.14,990.00");
		f2.add("6GB RAM");
		f2.add("64GB ROM");
		f2.add("6.41 inches");
		f2.add("12+5 MP Dual Rear Cameras");
		f2.add("25 MP Front Camera");
		f2.add("3400 mAh Battery");
		
		MobileFeatures mf3 = new MobileFeatures("Samsung Galaxy S20", null);
		List<String> f3 = new ArrayList<String>();
		f3.add("Rs. 99,890.00");
		f3.add("12GB RAM");
		f3.add("128GB ROM");
		f3.add("166.9mm x 76mm x 8.8mm");
		f3.add("1.4mMP Rear Camera");
		f3.add("108MP + 48MP + 12MP Front Camera");
		f3.add("5000 mAh Battery");
		
		featuresmap.put(mf1, f1);
		featuresmap.put(mf2, f2);
		featuresmap.put(mf3, f3);
		
		for(Entry<MobileFeatures, List<String>> mf : featuresmap.entrySet()) {
			System.out.println(mf.getKey().getModel());
			System.out.println(mf.getValue());
			System.out.println(" ");
		}
	
	}

}