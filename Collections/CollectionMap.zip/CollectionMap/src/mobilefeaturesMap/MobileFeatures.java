package mobilefeaturesMap;

import java.util.List;

public class MobileFeatures {

	String model;
	List<String> features;
	
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public List<String> getFeatures() {
		return features;
	}
	public void setFeatures(List<String> features) {
		this.features = features;
	}
	public MobileFeatures(String model, List<String> features) {
		super();
		this.model = model;
		this.features = features;
	}
}