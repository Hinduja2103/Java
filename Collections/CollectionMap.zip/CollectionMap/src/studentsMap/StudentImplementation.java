package studentsMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class StudentImplementation {

	public static void main(String[] args) {
		
		Map<Students,List<Integer>> studentmap = new HashMap<Students,List<Integer>>();
		
		Students s1 = new Students("Pinky", 101, "ECE", null);
		List<Integer> marks1 = new ArrayList<Integer>();
		marks1.add(95);
		marks1.add(89);
		marks1.add(79);
		marks1.add(67);
		marks1.add(99);
		
		Students s2 = new Students("Sonu", 202, "EIE", null);
		List<Integer> marks2 = new ArrayList<Integer>();
		marks2.add(94);
		marks2.add(98);
		marks2.add(89);
		marks2.add(88);
		marks2.add(99);
		
		Students s3 = new Students("Rinky", 303, "ME", null); 
		
		studentmap.put(s1, marks1);
		studentmap.put(s2, marks2);
		studentmap.putIfAbsent(s3, marks2);
		
		for (Entry<Students, List<Integer>> s : studentmap.entrySet()) {
			System.out.println(s.getKey().getSname());
			System.out.println(s.getKey().getRollno());
			System.out.println(s.getKey().getBranch());
			System.out.println(s.getValue());
			System.out.println("------------------------------------------------------------------------");	
		}
		
	}
	
}