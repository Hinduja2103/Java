package studentsMap;

import java.util.List;

public class Students {

	String sname;
	int rollno;
	String branch;
	List<Integer> marks;
	
	
	public Students(String sname, int rollno, String branch, List<Integer> marks) {
		super();
		this.sname = sname;
		this.rollno = rollno;
		this.branch = branch;
		this.marks = marks;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public List<Integer> getMarks() {
		return marks;
	}

	public void setMarks(List<Integer> marks) {
		this.marks = marks;
	}
}
