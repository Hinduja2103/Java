package programminglangMap;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class ProgramLanguageImplmentation {

	public static void main(String[] args) throws NumberFormatException,IOException {
		
		Map<ProgramLanguage, List<String>> pmap = new HashMap<ProgramLanguage, List<String>>();
		
		System.out.println("Enter range :");
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader bf= new BufferedReader(in);
		Integer n= Integer.valueOf(bf.readLine());
		
		for(int i=1; i<=n; i++) {
			ProgramLanguage plObject = new ProgramLanguage();
			
			System.out.println("Enter Programming Langauge "+i+" name :");
			String name = bf.readLine();
			
			System.out.println("Enter range for versions of Programming Language :");
			Integer m = Integer.valueOf(bf.readLine());
			List<String>  versions= new ArrayList<String>();
			for(int j=1; j<=m; j++) {
				System.out.println("Enter "+j+" version of Programming Language "+i+" :");
				versions.add(bf.readLine());
			}
			
			plObject.setName(name);
			plObject.setVersions(versions);
			pmap.put(plObject,(List<String>) versions);
		}
		
		for(Entry<ProgramLanguage, List<String>> p : pmap.entrySet()) {
			System.out.println(p.getKey().getName());
			System.out.println(p.getValue());
			System.out.println("-------------------------------------------------------------------------");
		}
	}
}
