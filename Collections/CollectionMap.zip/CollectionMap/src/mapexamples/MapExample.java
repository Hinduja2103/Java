package mapexamples;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapExample {

public static void main(String args[]) {
		
		
		Map<Integer,List<String>> map= new HashMap<>();
		List<String> name=new ArrayList<String>();
		name.add("Gaurav");
		name.add("Hinduja");
		name.add("Srikanth");
		name.add("yash");
		map.put(1,name);
		List<String> name1=new ArrayList<String>();
		name1.add("Gubbe");
		name1.add("Himaja");
		name1.add("Krishsrikanth");
		name1.add("Radhika");
		map.put(2,name1);
		
		
		System.out.println(map);
		System.out.println(map.keySet());
	}

}
