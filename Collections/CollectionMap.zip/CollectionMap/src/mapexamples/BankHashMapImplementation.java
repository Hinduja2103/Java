package mapexamples;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class BankHashMapImplementation {
 
	public static void main(String args[]) {
		
		Map<Bank,List<String>> map= new HashMap<>();
		
		Bank obj1= new Bank(1,"Axis Bank","IFCS89090",BigInteger.valueOf(907L),"Mumbai","Juhu",null);
		Bank obj2= new Bank(2,"ICICI Bank","IFCS89gfg",BigInteger.valueOf(967L),"Mumbai","Anderi",null);
		Bank obj3= new Bank(3,"HDFC Bank","IFCS88876",BigInteger.valueOf(957L),"Mumbai","JantrMantar",null);
		Bank obj4= new Bank(4,"SBI Bank","IFCS88876",BigInteger.valueOf(957L),"Mumbai","JantrMantar",null);

		List<String> obj1Loctions= new ArrayList<>();
		List<String> obj2Loctions= new ArrayList<>();
		List<String> obj3Loctions= new ArrayList<>();
		
		obj1Loctions.add("Bangalore");
		obj1Loctions.add("chennai");
		
		obj2Loctions.add("Trichy");
		obj2Loctions.add("Indore");
		
		obj3Loctions.add("Delhi");
		obj3Loctions.add("Nagpur");
		
		map.put(obj1, obj1Loctions);
		map.put(obj2, obj2Loctions);
		map.put(obj3, obj3Loctions);

		map.putIfAbsent(obj4, obj3Loctions);
		
		
		for (Entry<Bank, List<String>> m:map.entrySet()) {
			System.out.println(m.getKey().getName());
			System.out.println(m.getValue());
		}
		
	}

}
