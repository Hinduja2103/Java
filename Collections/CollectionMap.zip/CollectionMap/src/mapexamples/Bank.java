package mapexamples;

import java.math.BigInteger;
import java.util.List;

public class Bank {
	
	public Bank(Integer id, String name, String ifscCode, BigInteger accNum, String mainbranch, String address,
		List<String> locations) {
			super();
			this.id = id;
			this.name = name;
			this.ifscCode = ifscCode;
			this.accNum = accNum;
			this.mainbranch = mainbranch;
			this.address = address;
			this.locations = locations;
		}
	Integer id;
	String name;
	String ifscCode;
	BigInteger accNum;
	String mainbranch;
	String address;
	List<String> locations;
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the ifscCode
	 */
	public String getIfscCode() {
		return ifscCode;
	}
	/**
	 * @param ifscCode the ifscCode to set
	 */
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	/**
	 * @return the accNum
	 */
	public BigInteger getAccNum() {
		return accNum;
	}
	/**
	 * @param accNum the accNum to set
	 */
	public void setAccNum(BigInteger accNum) {
		this.accNum = accNum;
	}
	/**
	 * @return the mainbranch
	 */
	public String getMainbranch() {
		return mainbranch;
	}
	/**
	 * @param mainbranch the mainbranch to set
	 */
	public void setMainbranch(String mainbranch) {
		this.mainbranch = mainbranch;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the locations
	 */
	public List<String> getLocations() {
		return locations;
	}
	/**
	 * @param locations the locations to set
	 */
	public void setLocations(List<String> locations) {
		this.locations = locations;
	}
	
	
	
}
