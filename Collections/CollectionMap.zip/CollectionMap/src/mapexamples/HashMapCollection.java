package mapexamples;

import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapCollection {

	public static void main(String[] args) {

		Map<Integer, List<String>> m = new HashMap<Integer, List<String>>();
		
		List<String> names = new ArrayList<String>();
		names.add("Yashaswini");
		names.add("Srikanth");
		names.add("Gaurav");
		names.add("Shrinivas");
		
		m.put(1, names);
		
		List<String> names1 = new ArrayList<String>();
		names1.add("Hinduja");
		names1.add("Anil");
		names1.add("Manoj");
		names1.add("Yogitha");
		names1.add("Karthik");
		
		m.put(2, names1);
		
		Collection<Integer> n = m.keySet();
		System.out.println(n);
		Collection<List<String>> n1 = m.values(); 
		System.out.println(n1);
		Set<Entry<Integer, List<String>>> n2 = m.entrySet();
		System.out.println(n2);
	}

}