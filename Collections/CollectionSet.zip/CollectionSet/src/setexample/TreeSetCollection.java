package setexample;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetCollection {

	public static void main(String[] args) {

		Set<Integer> s = new TreeSet<Integer>();
		s.add(1);
		s.add(100);
		s.add(45);
		s.add(89);
		s.add(56);
		s.add(75);
		
		for(Integer n:s) {
			System.out.println(n);
		}
	}

}
