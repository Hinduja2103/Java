package setexample;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetCollection {

	public static void main(String[] args) {

		Set<Integer> s = new LinkedHashSet<Integer>();
		s.add(1);
		s.add(100);
		s.add(67);
		s.add(1);
		s.add(null);
		
		for(Integer n:s) {
			System.out.println(n);
		}
	}

}
