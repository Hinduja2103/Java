package setexample;

import java.util.HashSet;
import java.util.Set;

public class HashSetCollection {

	public static void main(String[] args) {
		
		Set<Integer> s = new HashSet<Integer>();
		s.add(null);
		s.add(1);
		s.add(2);
		s.add(3);
		s.add(3);
		s.add(100);
		s.add(75);
		
		for(Integer n:s) {
			System.out.println(n);
		}
	}

}
