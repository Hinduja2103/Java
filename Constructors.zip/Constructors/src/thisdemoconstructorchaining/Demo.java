package thisdemoconstructorchaining;

public class Demo {
	
	int a=10;
	int b=15;
	int c=20;
	
	Demo(int a){
		System.out.println(a);
	}
	
}
