package thisdemoconstructorchaining;

public class ThisMethodMainClass  {

	public static void main(String[] args) {

		@SuppressWarnings("unused")
		ThisMethodDemo t= new ThisMethodDemo();
		
	}

}
