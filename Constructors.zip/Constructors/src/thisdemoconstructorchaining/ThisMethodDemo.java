package thisdemoconstructorchaining;

public class ThisMethodDemo extends Demo {
	
	static int a;
	static int b;
	static int c;
	
	ThisMethodDemo(){
		this(a);
		System.out.println(a + " " + b +" " + c);
	}
	
	ThisMethodDemo(int a){
		this(a,b);
		System.out.println("1 parameterized constuctor : "+a + " " + b +" " + c);
	}
	
	ThisMethodDemo(int a,int b){
		this(a,b,c);
		System.out.println("2 parameterized constructor : "+a + " " + b +" " + c);
	}

	@SuppressWarnings("static-access")
	ThisMethodDemo(int a,int b, int c ){
		super(a);
		this.a=a;
		this.b=b;
		this.c=c;
		System.out.println("3 parameterized constructor : "+a + " " + b +" " + c);
	}
}
