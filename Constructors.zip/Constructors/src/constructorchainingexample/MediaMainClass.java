package constructorchainingexample;

public class MediaMainClass {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Media m = new Media();
	}

}
