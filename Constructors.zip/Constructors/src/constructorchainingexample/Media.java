package constructorchainingexample;

public class Media {

	static String s;
	static int i;
	
	Media() {
		this(s);
		System.out.println("Sakshi News");
	}
	
	Media(String s) {
		this(s,i);
		System.out.println("NDTV");
	}
	
	@SuppressWarnings("static-access")
	Media(String s,int i) {
		this.s = s;
		this.i = i;
		System.out.println("Public News");
	}
}
