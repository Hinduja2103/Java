package constructorchaining;

public class RestrauntMainClass {

	public static void main(String[] args) {
		
		@SuppressWarnings("unused")
		Restraunt r = new Restraunt("Ch.Lollipop","Ch.Biryani","Choclate Icecream");
		
	}

}
