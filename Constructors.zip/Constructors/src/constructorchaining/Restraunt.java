package constructorchaining;

public class Restraunt extends RestrauntDemo {
	
	static String s;
	static String mc;
	static String d;
	
	Restraunt() {
		this(s);
		System.out.println(s+" "+mc+" "+d);
	}
	
	Restraunt(String s) {
		this(s,mc);
		System.out.println(s+" "+mc+" "+d);
	}
	
	Restraunt(String s, String mc) {
		this(s,mc,d);
		System.out.println(s+" "+mc+" "+d);
	}
	
	@SuppressWarnings("static-access")
	Restraunt(String s, String mc, String d) {
		super(d);
		this.s = s;
		this.mc = mc;
		this.d = d;
		System.out.println(s+" "+mc+" "+d);
	}

}
