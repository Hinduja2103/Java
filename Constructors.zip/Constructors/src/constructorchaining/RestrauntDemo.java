package constructorchaining;

public class RestrauntDemo {

	String s = "Ch.Lollipops";
	String mc = "Ch.Biryani";
	String d = "Choclate Icecream";
	
	RestrauntDemo(String d) {
		System.out.println(d);
	}
}
