package thisconstructor;

public class Demo {
	
	int a=10;
	int b=15;
	int c=20;
	
	Demo(int a){
		System.out.println(a);
	}
	
	public static void main(String[] args) {
		DemoConstructor dc= new DemoConstructor();
		DemoConstructor dc1= new DemoConstructor();
		dc.display();
		dc1.display();
	}
}
