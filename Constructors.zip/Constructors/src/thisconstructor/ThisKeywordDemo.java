package thisconstructor;

public class ThisKeywordDemo extends Demo {
	
	static int a;
	int b;
	int c;
	
	ThisKeywordDemo() {
		super(a);
		System.out.println(a + " " + b +" " + c);
	}
	
	@SuppressWarnings("static-access")
	ThisKeywordDemo(int a) {
		super(a);
		this.a=a;
		System.out.println("1 parameterized constructor : "+a + " " + b +" " + c);
	}
	
	@SuppressWarnings("static-access")
	ThisKeywordDemo(int a,int b) {
		super(a);
		this.a=a;
		this.b=b;
		System.out.println("2 parameterized constructor : "+a + " " + b +" " + c);
	}
	
	@SuppressWarnings("static-access")
	ThisKeywordDemo(int a,int b,int c) {
		super(a);
		this.a=a;
		this.b=b;
		this.c=c;
		System.out.println("3 parameterized constructor : "+a + " " + b +" " + c);
	}
}
