package thisconstructor;

public class ThisDemoMainClass {
	
	@SuppressWarnings("unused")
	public static void main(String args[]) {
		
		ThisKeywordDemo t = new ThisKeywordDemo();
		ThisKeywordDemo t1 = new ThisKeywordDemo(2);
		ThisKeywordDemo t2 = new ThisKeywordDemo(2,3);
		ThisKeywordDemo t3 = new ThisKeywordDemo(2,3,4);

	}

}
