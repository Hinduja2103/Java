package thisconstructor;

public class DemoConstructor {

	static {
		System.out.println(" Boss i am static block , boss of your execution flow");
	}
	
	public DemoConstructor() {
		System.out.println("I am default constructor");
	}
	
	public DemoConstructor(String s) {
		System.out.println( s +"I am parameterized constructor");
	}

	void display() {
		System.out.println("I am method");
	}
}


