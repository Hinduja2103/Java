package constructors;

public class Constructors {
	
	Constructors() {
		
		System.out.println("hello constructors");
	}

	public static void main(String[] args) {
		
		System.out.println("hello i am a constructor");
		
		Constructors c = new Constructors();
		
		System.out.println(c);
	}

}
