package constructors;

public class Employee {
	
	int age;
	String name;
	String mailid;
	
	Employee() {
		
	    age = 24;
		name = "Hinduja";
		mailid = "hinduja@gmail.com";
	}
	
	void display() {
		
		System.out.println("Age : "+age);
		System.out.println("Name : "+name);
		System.out.println("Mail id : "+mailid);
	}

	public static void main(String[] args) {
		
		Employee e = new Employee();
		e.display();
	}

}
