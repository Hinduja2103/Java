package constructor_overriding;

public class Vehicles {

	public static void main(String[] args) {
		
		System.out.println("Types of vehicles");
		
		class Bike extends Vehicles {
			
			int wheels = 2;
			String reversegear = "No";
				
			void print() {
				System.out.println("Bikes");
				System.out.println("Wheels : "+wheels);
				System.out.println("Reverse gear applied : "+reversegear);
			}
		}
		
		class Car extends Vehicles {
			
			int wheels = 4;
			String reversegear = "Yes";
			
			void print() {
				System.out.println("Cars");
				System.out.println("Wheels : "+wheels);
				System.out.println("Reverse gear applied : "+reversegear);
			}
		}

		Bike b = new Bike();
		b.print();
		Car c = new Car();
		c.print();
	}
}
