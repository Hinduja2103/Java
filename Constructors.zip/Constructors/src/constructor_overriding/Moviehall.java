package constructor_overriding;
/**
 * 
 * @author HINDUJA
 *
 */
public class Moviehall {
   
	String name;
	int seats;
    String ac;
    float popcorn;
    
    void display() {
		
    	 System.out.println(name);
     	 System.out.println("seating capacity : "+seats);
         System.out.println("ac availability : "+ac);
         System.out.println("pop corn price : "+popcorn);
	}
    
    class theatres extends Moviehall {
        
    	theatres(String n, int s, String a, float p)
        {
    		name = n;
            seats = s;
            ac = a;
            popcorn = p;
        }
    }
   
    class multiplexes extends Moviehall {
       
		multiplexes(String n, int s, String a, float p)
        {
		   name = n;
           seats = s;
           ac = a;
           popcorn = p;
        }
    }
    
    public static void main(String args[]) {   
        
    	Moviehall x = new Moviehall();
        theatres t = x.new theatres("Theatres", 200, "No", 50.00f);
        t.display();
        multiplexes m =x.new multiplexes("Multiplexes", 100, "Yes", 250.00f);
        m.display();
    }
}
 
