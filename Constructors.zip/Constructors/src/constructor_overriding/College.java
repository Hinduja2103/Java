package constructor_overriding;

public class College {
	
	String name;
	int students;
	int branches;
	int faculty;
	float fees;

	void display() {
		
		System.out.println("College Name : "+name);
		System.out.println("No. of Students : "+students);
		System.out.println("No. of Branches : "+branches);
		System.out.println("No.of faculty : "+faculty);
		System.out.println("College Fee : "+fees);
	}
	
	class College1 extends College {
		
		College1(String n, int s, int b, int f, float p) {
			name = n;
			students = s;
			branches = b;
			faculty = f;
			fees = p;
		}
	}
	
	class College2 extends College {
		
		College2(String n, int s, int b, int f, float p) {
			name = n;
			students = s;
			branches = b;
			faculty = f;
			fees = p;
		}
	}
	
	public static void main(String[] args) {
		
		College c = new College();
		College1 c1 = c.new College1("AIT",5000,6,60,130000.00f);
		c1.display();
		System.out.println(" ");
		College2 c2 = c.new College2("BIT",7000,8,80,150000.00f);
		c2.display();
	}

}
