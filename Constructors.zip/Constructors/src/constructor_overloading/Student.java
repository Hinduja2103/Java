package constructor_overloading;

public class Student {
	
	int rollno;
	String name;
	int age;
	
	Student(int r) {
		rollno = r;
	}
	
	Student(int r, String n) {
		rollno = r;
		name = n;
	}
	
	Student(int r, String n, int a) {
		rollno = r;
		name = n;
		age = a;
	}
	
	void display() {
		System.out.println("Roll no : "+rollno);
		System.out.println("Name : "+name);
		System.out.println("Age : "+age);
	}
	public static void main(String[] args) {
		
		Student s1 = new Student(101);
		Student s2 = new Student(101,"Hinduja");
		Student s3 = new Student(101,"Hinduja",24);
		s1.display();
		s2.display();
		s3.display();
	}

}
