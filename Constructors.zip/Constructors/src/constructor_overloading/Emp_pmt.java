package constructor_overloading;

public class Emp_pmt {
	
	int id;
	String name;
	int age;
	String mailid;
	int salary;
	
	Emp_pmt(int i, String s1, int a) {
		
		id = i;
		name = s1;
		age = a;
	}
	
	Emp_pmt(String s2, int s) {
		
		mailid = s2;
		salary = s;
	}
	
	void display() {
		
		System.out.println("Id : "+id);
		System.out.println("Name : "+name);
		System.out.println("Age : "+age);
	}
	
	void print() {
		
		System.out.println("Mail id : "+mailid);
		System.out.println("Salary :"+salary);
	}

	public static void main(String[] args) {
		
		Emp_pmt e1 = new Emp_pmt(101, "Hinduja", 24);
		e1.display();
		Emp_pmt e2 = new Emp_pmt("hinduja@gmail.com", 50000);
		e2.print();

	}

}
