package modifiers_execution;

public class ProtectedClassEx {
	 
	protected class HelloProtected{	
		 void display() {
			 System.out.println("hello");
		 }
	 }
	 
	 @SuppressWarnings("null")
	public static void main(String[] args) {
		 ProtectedClassEx.HelloProtected hp = null;
		 hp.display();
	 }
}

