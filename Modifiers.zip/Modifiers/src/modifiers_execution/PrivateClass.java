package modifiers_execution;

public class PrivateClass {
	
	@SuppressWarnings("unused")
	private class Hello{
		
		int i=0;
		void display() {
			System.out.println("hello am private class, you cant see me");
		}
	}
}
