package modifiers_execution;

public class PublicClass extends ProtectedClassEx {

	public int i = 10;
	
	public void display() { 
		System.out.println(i);
	}
}
