package modifiers_execution;

public class MainExample {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		PrivateClass pc= new PrivateClass();
	}

}

