package modifiers;

import modifiers_execution.PublicClass;

public class ModifiersExecution {

     public static void main(String args[]) {
    	 
    	 PublicClass pc=new PublicClass();
    	 pc.display();
    	 
    	 FinalClassDemo f= new FinalClassDemo();
    	 f.display();
     }
	
}

