package modifiers;

public final class FinalClassDemo {

	void display() {
		System.out.println(" hello i am final class method");
	}	
}