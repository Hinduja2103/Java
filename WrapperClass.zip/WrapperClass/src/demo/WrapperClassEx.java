package demo;

import java.math.BigInteger;

public class WrapperClassEx {
	
	public static void main (String[] args) {
			
		Integer i= Integer.max(10,20);
		BigInteger bi=BigInteger.ONE;
		Integer n = Integer.SIZE; 
				  
		System.out.println(i);
		
		System.out.println(bi);
		
		System.out.println(n);
	}

}
