package functionspackage;

import functions.*;

public class ArithmeticFunctions {

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		
		FunctionsWithReturntypeNoArgs a = new FunctionsWithReturntypeNoArgs();
		
		a.addition();
		a.subtraction();
		a.multiplication();
		a.division();
		
		PowerWithReturntypeNoArgs p = new PowerWithReturntypeNoArgs();
		
		p.square();
		p.cube();
		
		GreatestWithFunctions g = new GreatestWithFunctions();
		
		g.greatest();
		g.smallest();
	}

}
