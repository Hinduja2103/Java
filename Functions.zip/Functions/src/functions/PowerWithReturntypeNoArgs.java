package functions;

public class PowerWithReturntypeNoArgs {
	
	static int n = 2;
	static int c;
	static int d;

	public static int square() {
		return(c = n*n);
	}
	
	public static int cube() {
		return(d = n*n*n);
	}
	
	public static void main(String[] args) {
		
		square();
		cube();
		
		System.out.println("Square of a number is : "+c);
		System.out.println("Cube of a number is : "+d);

	}

}
