package functions;

public class PowerWithArgsAndReturntype {
	
    static int a = 3;
	static int c;
	static int d;
	
	public static void main(String[] args) {
		
		square(a);
		cube(a);
		
		System.out.println("Square of a number is : "+c);
		System.out.println("Cube of a number is : "+d);

	}
	
	private static int square(int x) {
		return(c = x*x);
	}
	
	private static int cube(int y) {
		return(d = y*y*y);
	}

}
