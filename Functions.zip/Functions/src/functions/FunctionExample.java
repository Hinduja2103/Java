package functions;

public class FunctionExample {

	public static void main(String[] args) {
		
		System.out.println("Functions Demo");
		
		display();

	}
	
	static void display() {
		
		System.out.println("Hello welcome to Functions Demo");
	}

}
