package functions;

public class FunctionsWithReturntypeArgs {
	
	static int a = 10;
	static int b = 20;
	
	private static int addition(int a, int b) {
		return(a+b);
	}
	
	private static int subtraction(int x, int y) {
		return(y-x);			
	}
	
	private static int multiplication(int y, int z) {
		return(y*z);
	}
	
	private static int division(int c, int d) {
		return(d/c);
	}
		
	public static void main(String[] args) {
			
		addition(a, b);
	    subtraction(a,b);
		multiplication(a,b);
		division(a,b);
		
		System.out.println("Addition of 2 numbers : "+(a+b));
		System.out.println("subtraction of 2 numbers : "+(b-a));
		System.out.println("Multiplication of 2 numbers : "+(a*b));
		System.out.println("Division of 2 numbers : "+(b/a));
	}	       

}
