package functions;

public class FunctionsWithReturntypeNoArgs {
	
	static int a = 10;
	static int b = 20;
				
	public static int addition() {
		return(a+b);
	}
	
	public static int subtraction() {
		return(b-a);
	}
	
	public static int multiplication() {
		return(a*b);
	}
	
	public static int division() {
		return(b/a);
	}
	
	public static void main(String[] args) {
		
		addition();
		subtraction();
		multiplication();
		division();
		
		System.out.println("Addition of 2 numbers : "+(a+b));
		System.out.println("subtraction of 2 numbers : "+(b-a));
		System.out.println("Multiplication of 2 numbers : "+(a*b));
		System.out.println("Division of 2 numbers : "+(b/a));
	}
	       
}
