package functions;

public class GreatestWithFunctions {

	static int a = 10;
	static int b = 20;
	static boolean c;
	static boolean d;
	
	public static void main(String[] args) {
		
		greatest();
		smallest();
		
		System.out.println(c);
		System.out.println(d);
	}
	
	public static boolean greatest() {
		return(c = (a>b));
	}
	
	public static boolean smallest() {
		return(d = (b>a));
	}
}