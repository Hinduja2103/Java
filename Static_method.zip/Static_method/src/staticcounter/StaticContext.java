package staticcounter;

class StaticContext{

	int a=10;
	static int b=20;
	
	void hi()
	{
		helloworld();
	
		System.out.println("non static method");
	}

	static void helloworld()
	{
		System.out.println("static context");
	}
	
	public static void main(String[] args) {
		
		StaticContext d = new StaticContext();
		d.hi();
		StaticContext.helloworld();	
	}

}
