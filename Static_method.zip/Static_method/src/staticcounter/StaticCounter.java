package staticcounter;

public class StaticCounter {
	
    static int a = 10;
	
	static void staticcounter() {
		
		a++;
		System.out.println(a);
	}
	
	static {
		System.out.println("static counter");
	}
	
	static class StaticContext {
		
		void display()
		{
			System.out.println("i am a static class");
		}
	}
	public static void main(String args[]) {

		StaticCounter.staticcounter();
		StaticCounter.staticcounter();
		StaticCounter.StaticContext sc = new StaticCounter.StaticContext();
		sc.display();
	}

}
