package staticmethod;
/**
 * 
 * @author HINDUJA
 *
 */

public class StaticMethod {
	
	static void display() {
	
    int a = 3;
	
	int b = 5;
	
	int sum = a + b;
	{
		System.out.println("the sum is : "+sum);
	}
	int difference = b - a;
	{
		System.out.println("the difference is : "+difference);
	}
	int product = a * b;
	{
		System.out.println("the product is : "+product);
	}
	double quotient = b/a;
	{
		System.out.println("the quotient is : "+quotient);
	}
	if (a>b)
	{
		System.out.println("a is greater");
	}
	else 
	{
		System.out.println("b is greater");
	}
	if (a<b)
	{
		System.out.println("a is smaller");
	}
	else
	{
		System.out.println("b is smaller");
	}

}
	static {
		System.out.println("basic arithmetic operations");
	}

	public static void main(String[] args) {
		
		StaticMethod.display();
		
	}

}
