package staticmethod;

public class Greetings {
	
	void print()
	{
		System.out.println("Hello World");
	}
	
	static void hello()
	{
		System.out.println("non static context");
	}
	
	public static class Hello
	{
		public static void main(String args[])
		
		{
			Greetings g = new Greetings();
			
			g.print();
			
			hello();
			
		}
	}


}
