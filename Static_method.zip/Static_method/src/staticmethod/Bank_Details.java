package staticmethod;

public class Bank_Details {

	void display()
	
	{
		int an = 1234567890;
		String name = "Hinduja";
		float da = 34000.00f;
		float wa = 23000.00f;
		float ba = da - wa;
		
		{
			System.out.println("Account number : "+an);
			System.out.println("Name : "+name);
			System.out.println("Amount Deposited : "+da);
			System.out.println("Amount Withdraw : "+wa);
			System.out.println("Balance Amount : "+ba);
		}
	}
	
	static 
	{
		System.out.println("Bank : SBI");
	}
	
	public static void main(String[] args) {
			
			Bank_Details bd = new Bank_Details();
			bd.display();
	}

}
