package staticmethod;

import java.util.Scanner;

public class Bank1 {
	
	private static Scanner sc;

	static void display()
    {
        sc = new Scanner(System.in);
        
        System.out.println("enter account number");
        @SuppressWarnings("unused")
		int an = sc.nextInt();
        
        System.out.println("enter name");
        @SuppressWarnings("unused")
		String name = sc.next();
        
        System.out.println("enter deposit amount");
        double da = sc.nextDouble();
        
        System.out.println("enter withdraw amount");
        double wa = sc.nextDouble();
        
        double ba = da-wa;
        System.out.println("Balance amount : "+ba);
    }
    
	static
    {
        String str = "SBI";
        System.out.println("Bank name : "+str);
    }
    
	public static void main(String args[])
    {
        Bank1.display();
    }

}
