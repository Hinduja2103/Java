package comparator;

import java.util.ArrayList;
import java.util.Collections;

public class ListSorting {
	
	public static void main(String args[]) {
		
		ArrayList<Integer> hs= new ArrayList<Integer>();
		
		hs.add(5);
		hs.add(100);
		hs.add(89);
		hs.add(90);
		hs.add(76);
		hs.add(99);
		
		Collections.sort(hs);
		for(Integer i:hs) {
			System.out.println(i);
		}
		
	}

}