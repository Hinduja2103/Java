package comparator;

import java.math.BigInteger;
import java.util.List;

public class Bank implements Comparable<Bank> {
	
	
	Integer id;
	String name;
	String ifscCode;
	BigInteger accNum;
	String mainbranch;
	String address;
	List<String> locations;
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getIfscCode() {
		return ifscCode;
	}
	
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	
	public BigInteger getAccNum() {
		return accNum;
	}
	
	public void setAccNum(BigInteger accNum) {
		this.accNum = accNum;
	}
	
	public String getMainbranch() {
		return mainbranch;
	}
	
	public void setMainbranch(String mainbranch) {
		this.mainbranch = mainbranch;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public List<String> getLocations() {
		return locations;
	}
	
	public void setLocations(List<String> locations) {
		this.locations = locations;
	}

	@Override
	public int compareTo(Bank o) {
		
		if(id==o.getId()) {
			return 0;
		}
		else if(id>o.getId()) {
			return 1;
		}
		else {
			return -1;	
		}
	}
}
