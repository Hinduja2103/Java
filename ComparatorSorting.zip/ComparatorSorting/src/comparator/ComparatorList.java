package comparator;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;

public class ComparatorList {
	
	public static void main(String args[]) {
		
		ArrayList<Bank> bl= new ArrayList<Bank>();
		Bank b1= new Bank();
		b1.setId(78);
		b1.setName("HDFC");
		b1.setIfscCode("HDFC0000264");
		b1.setAccNum(BigInteger.valueOf(86L));
		bl.add(b1);
		
		Bank b2= new Bank();
		b2.setId(56);
		b2.setName("Axis");
		b2.setIfscCode("Axis0000264");
		b2.setAccNum(BigInteger.valueOf(7L));
		bl.add(b2);

		Bank b3= new Bank();
		b3.setId(34);
		b3.setName("SBI");
		b3.setIfscCode("SBI0000264");
		b3.setAccNum(BigInteger.valueOf(10L));
		bl.add(b3);

		Collections.sort(bl);
		for(Bank b:bl) {
			System.out.println(b.getId() +"--"+b.getName());
		}
				
	}

}