package mobileComparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MobileListComparator {

	public static void main(String[] args) {

		List<MobileList> moblist = new ArrayList<MobileList>();
		
			MobileList m1 = new MobileList();
			m1.setName("iPhone");
			m1.setModel("X Max");
			m1.setPrice(1500.00f);
			m1.setRam(8);
			m1.setRom(128);
			
			MobileList m2 = new MobileList();
			m2.setName("OnePlus");
			m2.setModel("7t Pro");
			m2.setPrice(1300.00f);
			m2.setRam(6);
			m2.setRom(64);
			
			MobileList m3 = new MobileList();
			m3.setName("Redmi");
			m3.setModel("Note 5 Pro");
			m3.setPrice(190.00f);
			m3.setRam(4);
			m3.setRom(32);
			
			moblist.add(m1);
			moblist.add(m2);
			moblist.add(m3);
		
		Collections.sort(moblist);
		for(MobileList m:moblist) {
			System.out.println(m.getPrice() +"--"+m.getName());
		}
	
	}

}