package mobileComparator;

public class MobileList implements Comparable<MobileList> {

	String name;
	String model;
	float price;
	int ram;
	int rom;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getRam() {
		return ram;
	}

	public void setRam(int ram) {
		this.ram = ram;
	}

	public int getRom() {
		return rom;
	}

	public void setRom(int rom) {
		this.rom = rom;
	}

	@Override
	public int compareTo(MobileList o) {
		
		if(price==o.getPrice()) {
			return 0;
		}
		else if(price>o.getPrice()) {
			return 1;
		}
		else {
			return -1;	
		}
		
	}

}