package studentmarkscomparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StudentMarksComparator {

	public static void main(String[] args) {

		List<StudentMarks> sm = new ArrayList<StudentMarks>();
		
		StudentMarks s1 = new StudentMarks();
		s1.setName("Pinky");
		s1.setRollno(101);
		s1.setAge(24);
		s1.setTotalmarks(579);
		
		StudentMarks s2 = new StudentMarks();
		s2.setName("Sonu");
		s2.setRollno(202);
		s2.setAge(19);
		s2.setTotalmarks(589);
		
		StudentMarks s3 = new StudentMarks();
		s3.setName("Rinky");
		s3.setRollno(303);
		s3.setAge(15);
		s3.setTotalmarks(599);
		
		StudentMarks s4 = new StudentMarks();
		s4.setName("Hinduja");
		s4.setRollno(404);
		s4.setAge(24);
		s4.setTotalmarks(579);
		
		sm.add(s1);
		sm.add(s2);
		sm.add(s3);
		sm.add(s4);
		
		Collections.sort(sm);
		for(StudentMarks s : sm) {
			System.out.println(s.getAge()+"--"+s.getName());
		}
		
		Collections.sort(sm);
		for(StudentMarks m : sm) {
			System.out.println(m.getTotalmarks()+"--"+m.getName());
		}
	}

}
