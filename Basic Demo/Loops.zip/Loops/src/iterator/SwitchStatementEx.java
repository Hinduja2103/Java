package iterator;

import java.util.Scanner;

public class SwitchStatementEx {
	
	private static Scanner s;

	public static void main(String[] args) {
		
		s = new Scanner(System.in);
		System.out.println("Enter the below choice");
		System.out.println("Enter the 1 : To print any mathematical table");

		int n = s.nextInt();
		while(true) {	
		
			switch(n) {
			case 1:
				System.out.println("Enter any number");
				System.out.println("Enter the 0 : To exit from program");
	
			int j = s.nextInt();
			if(j==0) 
				System.exit(0);
			for(int i=1;i<=10;i++) {			
				System.out.println(j*i);
			}
			break;
		
			case 0:
			System.exit(0);
		
			default:
			System.out.println("hello i am deafult");
		
			}
			
		}
		
	}

}
