package iterator;

import java.util.Scanner;

public class ForLoop {

	private static Scanner s;

	public static void main(String[] args) {
		

		s = new Scanner(System.in); 
		System.out.println("Enter the number");
		int n = s.nextInt();
				
		for(int i=1;i<=10;i++) {			
			System.out.println(n*i);
		     if(i%5==0) {
		    	 System.exit(0);
		     } 	 
		     }
		System.out.println("bye");
		}

	}


