package demo;

public class Helloworld {

	public static void main(String[] args) {
		
		System.err.println("hello world");
	}

}
