package maindemo;

public class EvenorOdd {

	public static void main(String[] args) {
		
		int num = 13;
        
		if(num%2==0)
        {
            System.out.println("even number");
        }
        else
        {
            System.out.println("odd number");
        }

	}

}
