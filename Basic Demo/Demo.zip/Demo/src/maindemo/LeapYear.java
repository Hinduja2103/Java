package maindemo;

public class LeapYear {

	public static void main(String[] args) {
		
		int year = 2021;
        
		if (year%4==0)
        {
            System.out.println("leap year");
        }
        else
        {
            System.out.println("not a leap year");
        }
	
	}

}
