package maindemo;

public class MainDemo {

	public static void main(String[] args) {
		
		System.out.println("your first argument is :"+args[0]);
	}

}
