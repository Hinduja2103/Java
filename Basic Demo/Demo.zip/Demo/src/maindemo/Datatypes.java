package maindemo;

public class Datatypes {

	public static void main(String[] args) {
		
		int a,b,c;
        a = 10; 
        b = 20; 
        c = a+b;
        
        System.out.println("result1="+c);
        
        float a1,b1,c1;
        a1 = 10.0f;
        b1 = 20.0f;
        c1 = a1 * b1;
        
        System.out.println("result2="+c1);
        
        double a11,b11,c11;
        a11 = 50.0d;
        b11 = 50.0d;
        c11 = a11/b11;
        
        System.out.println("result3="+c11);
        
        char k;
        k = 'z';
        
        System.out.println("result4="+k);
        
        String content="Besant Technologies";
        
        System.out.println(content);
	}

}
