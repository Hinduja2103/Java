package basic;

import java.util.Scanner;

public class SquareCube {

	private static Scanner sc;

	public static void main(String[] args) {
		
		sc = new Scanner(System.in); 
		System.out.println("Enter the number");
		int n = sc.nextInt();
		
		System.out.println(Math.pow(n,2));
		System.out.println(Math.pow(n,3));
	}

}
