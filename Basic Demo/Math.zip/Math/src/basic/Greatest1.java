package basic;

public class Greatest1 {

	public static void main(String[] args) {
		
		int a = 3;
		
		int b = 1;
		
		if (a>b)

			System.out.println("a is greater");
		
		else
			
			System.out.println("b is greater");
	}

}
