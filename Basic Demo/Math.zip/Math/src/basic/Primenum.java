package basic;

import java.util.Scanner;

public class Primenum {

	private static Scanner sc;

	public static void main(String[] args) {
	
		sc = new Scanner(System.in); 
		System.out.println("Enter the number");
		int n = sc.nextInt();
		int count = 0;
		int i;
		
		for (i=1;i<=n;i++) {
			
			if (n%i==0) 
			count++;
		}
		
		if(count==2) {
			System.out.println("it is a prime number");
		}
		else {
			System.out.println("it is not a prime number");
		}
		
	}

}
