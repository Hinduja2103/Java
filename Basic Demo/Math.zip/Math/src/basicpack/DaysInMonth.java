package basicpack;

import java.util.*;

public class DaysInMonth {

	private static Scanner s;

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		
		s = new Scanner(System.in);
		System.out.println("Enter the month");
		String m = s.next();
		System.out.println("Enter the year");
		int y = s.nextInt();
	
		Calendar cal = Calendar.getInstance();
		int days = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		System.out.println("Number of days : "+days);
	}

}
