package basicpack;

import java.util.Scanner;

public class GcdnLcm{

	private static Scanner s;

	public static void main(String[] args) {
		
		s = new Scanner(System.in);
		System.out.println("enter the two numbers");
		int a = s.nextInt();
		int b = s.nextInt();
		int i,n,gcd = 0;
		
		n = a*b;
		for(i=1; i<=n; i++) {
			if((a%i==0) && (b%i==0)) {
				gcd = i;
			}
		}
		
		System.out.println("The GCD of the given two numbers is : "+gcd);
		
		int lcm = (a*b)/gcd;
		
		System.out.println("The LCM of the given two numbers is : "+lcm);
	}

}
