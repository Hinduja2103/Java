package basicpack;

public class PrimeNum {

	public static void main(String[] args) {
		
		String j = "";
		
		for(int n=1; n<=100; n++) {
			int count = 0;
			for (int i=n;i>=1;i--) {
					
				if (n%i==0) 
				count++;
			}
			
			if(count==2) {
				j = j+n+" ";
			}
		}
		System.out.println(j);
	}
}
