package basicpack;

public class SquareNum {

	public static void main(String[] args) {
		
		int i = 1; 
		for(int n=1; n<100; n++) {
		    n = (int) Math.pow(i,2);
			System.out.println(n);
			i++;
		}
	
	}

}
