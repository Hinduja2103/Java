package basicpack;

import java.util.Calendar;
import java.util.Scanner;

public class DayOfWeek {

	private static Scanner s;

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		
		s = new Scanner(System.in);
		System.out.println("Enter the date");
		int d = s.nextInt();
		System.out.println("Enter the month");
		String m = s.next();
		System.out.println("Enter the year");
		int y = s.nextInt();
		
		Calendar cal = Calendar.getInstance();
		int day = cal.getActualMaximum(Calendar.DAY_OF_WEEK);
		System.out.println("Day of a Week : "+day);
	}

}
