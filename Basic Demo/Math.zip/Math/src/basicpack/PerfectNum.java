package basicpack;

import java.util.Scanner;

public class PerfectNum {

	private static Scanner s;

	public static void main(String[] args) {
		
		s = new Scanner(System.in);
		System.out.println("enter the num");
		int n = s.nextInt();
		int i,sum = 0;
		
		for(i=1;i<=n/2;i++) {
			if(n%i==0) {
				sum = sum+i;
			}
		}
		
		if(sum==n) {
			System.out.println("It is a perfect number");
		}
		else {
			System.out.println("It is not a perfect number");
		}
	
	}

}
