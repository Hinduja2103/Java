package basicpack;

import java.util.Scanner;

public class StrongNum {

	private static Scanner sc;
	
	static int fact(int n) {
		if(n==1)
			return 1;
		else {
			return(n*fact(n-1));
		}
	}
	public static void main(String[] args) {
		
		sc = new Scanner(System.in);
		System.out.println("enter the num : ");
		int n = sc.nextInt();
		int o,r,s = 0;
		o = n;
		
		while(n!=0) {
			r = n%10;
			s = s+fact(r);
			n = n/10;
		}
		
		if(o==s) {
			System.out.println(o+" is a strong number");
		}
		else {
			System.out.println(o+" is not a strong number");
		}
	}
}
