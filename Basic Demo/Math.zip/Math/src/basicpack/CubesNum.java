package basicpack;

public class CubesNum {

	public static void main(String[] args) {
		
		int i = 1; 
		for(int n=1; n<100; n++) {
		    n = (int) Math.pow(i,3);
			System.out.println(n);
			i++;
		}

	}

}
