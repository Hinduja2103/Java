package basicpack;

import java.util.Scanner;

public class BinaryNum {

	private static Scanner s;

	public static void main(String[] args) {
		
		s = new Scanner(System.in);
		System.out.println("enter the num");
		int n = s.nextInt();
		
		String i = Integer.toBinaryString(n);
		
		System.out.println(i);

	}

}
