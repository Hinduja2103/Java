package basicpack;

import java.util.Scanner;

public class SumOfaNum {

	private static Scanner s;

	public static void main(String[] args) {
		
		s = new Scanner(System.in);
		System.out.println("enter the num");
		int n = s.nextInt();
		int d,sum = 0;
		
		while(n>0) {
			d = n%10;
			n = n/10;
			sum = sum + d;
		}
		
		System.out.println("Sum of the given number is : "+sum);

	}

}
