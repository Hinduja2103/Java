package mathpack;

public class Square {

	public static void main(String[] args) {
		
		int side = 4;
		
		int area;
		
		area = side*side;
		
		System.out.println("the area of a square is : "+area);
		
	}

}
