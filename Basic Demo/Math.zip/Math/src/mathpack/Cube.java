package mathpack;

public class Cube {

	public static void main(String[] args) {
		
		int side = 5;
		
		int volume;
		
		volume = side*side*side;
		
		System.out.println("the volume of a cube is : "+volume);
		
	}

}
