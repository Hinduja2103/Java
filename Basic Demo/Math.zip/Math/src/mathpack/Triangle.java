package mathpack;

public class Triangle {

	public static void main(String[] args) {
		
		float base = 2.5f;
		
		float height = 3.5f;
		
		final float A = 0.5f;
		
		float area;
		
		area = base*height*A;
		
		System.out.println("the area of a triangle is : "+area);
	}

}
