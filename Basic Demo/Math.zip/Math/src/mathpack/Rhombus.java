package mathpack;

public class Rhombus {

	public static void main(String[] args) {
		
		float d1=2.0f;
		
		float d2=3.0f;
		
		float area;
		
		final float A = 0.5f;
		
		area=((d1*d2)*A);
		
		System.out.println("the area of a rhombus is : "+area);
	}

}
