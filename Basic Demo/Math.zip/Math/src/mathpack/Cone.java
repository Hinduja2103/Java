package mathpack;

public class Cone {

	public static void main(String[] args) {
		
		float height = 6.5f;
		
		float radius = 2.0f;
		
		float volume;
		
		final float PI = 3.14f;
		
		final float A = 0.33f;
		
		volume = ((PI*radius*radius*height)*A);
		
		System.out.println("the volume of a cone is : "+volume);
	}

}
