package mathpack;

public class Parallelogram {

	public static void main(String[] args) {
		
		float base = 12.0f;
		
		float height = 13.0f;
		
		float area;
		
		area = base * height;
		
		System.out.println("the area of parallelogram is : "+area);
		
	}

}
