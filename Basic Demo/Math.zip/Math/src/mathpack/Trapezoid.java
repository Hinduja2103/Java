package mathpack;

public class Trapezoid {

	public static void main(String[] args) {
		
		int b1 = 3;
		
		int b2 = 5;
		
		int height = 4;
		
		final float A = 0.5f;
		
		float area;
		
		area = (b1+b2)*height*A;
		
		System.out.println("the area of a trapezoid is : "+area);
		
	}

}
