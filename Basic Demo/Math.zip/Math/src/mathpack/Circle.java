package mathpack;

public class Circle {

	public static void main(String[] args) {
		
		float radius = 2.4f;
		
		final float PI = 3.14f;
		
		final int A = 2;
		
		float circumference;
		
		circumference = A*PI*radius;
		
		System.out.println("the circumference of a circle is : "+circumference);

	}

}
