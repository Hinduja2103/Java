package mathpack;

public class Sphere {

	public static void main(String[] args) {
		
		int radius = 3;
		
		final float PI = 3.14f;
		
		float volume;
		
		final float A = 1.33f;
		
		volume = PI*radius*radius*radius*A;
		
		System.out.println("the volume of a sphere is : "+volume);
	}

}
