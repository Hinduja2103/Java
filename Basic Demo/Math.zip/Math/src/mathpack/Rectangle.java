package mathpack;

public class Rectangle {

	public static void main(String[] args) {
		
		int base = 4;
		
		int lenght = 5;
		
		int perimeter;
		
		final int A = 2;
		
		perimeter = (base+lenght)*A;
		
		System.out.println("the perimeter of a rectangle is : "+perimeter);
	}

}
