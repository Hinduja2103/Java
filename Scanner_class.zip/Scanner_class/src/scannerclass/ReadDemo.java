package scannerclass;

import java.util.Scanner;

public class ReadDemo {

	private static Scanner sc;

	public static void main(String[] args) {
		
		sc = new Scanner(System.in); 
		
		System.out.println("enter the text");
		
		String str = sc.nextLine();
		
		System.out.println(str);

	}

}