package scannerclass;

import java.util.Scanner;

public class Marks {

	private static Scanner s;

	public static void main(String[] args) {
		
		s = new Scanner(System.in);
		
		System.out.println("enter maths marks");
		int a = s.nextInt();
		
		System.out.println("enter science marks");
		int b = s.nextInt();
		
		System.out.println("enter social marks");
		int c = s.nextInt();
		
		System.out.println("enter kannada marks");
		int d = s.nextInt();
		
		System.out.println("enter english marks");
		int e = s.nextInt();
		
		int t = a+b+c+d+e;
		System.out.println("Total : "+t);
		
		double average = t/5;
		System.out.println("Average : "+average);
		
		if (t>=300 && t<350)
		{
			System.out.println("D grade");
		}
		else if (t>=350 && t<400)
		{
			System.out.println("C garde");
		}
		else if (t>=400 && t<450)
		{
			System.out.println("B grade");
		}
		else if (t>=450 && t<500)
		{
			System.out.println("A grade");
		}
		else
		{
			System.out.println("E grade");
		}

	}

}
