package scannerclass;

import java.util.Scanner;

public class Greatest {

	private static Scanner s;

	public static void main(String[] args) {
		
		s = new Scanner(System.in);
		
		System.out.println("enter the frst num");
		
		int a = s.nextInt();
		
		System.out.println("enter the second num");
		
		int b = s.nextInt();
		
		if (a>b)
			
			System.out.println("a is greater "+a);
		
		else 
			
			System.out.println("b is greater "+b);
	}

}
