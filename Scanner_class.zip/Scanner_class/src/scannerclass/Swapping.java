package scannerclass;

import java.util.Scanner;

public class Swapping {

	private static Scanner sc;

	public static void main(String[] args) {
		
		sc = new Scanner(System.in);
		
		System.out.println("enter the first num");
		
		int a = sc.nextInt();
		
		System.out.println("enter the second num");
		
		int b = sc.nextInt();
		
		int temp = 0;
		
		temp = a;
		
		a = b;
		
		b = temp;
		
		System.out.println(a);
		
		System.out.println(b);
	}

}
