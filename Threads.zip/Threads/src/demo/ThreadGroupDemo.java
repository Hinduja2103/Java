package demo;

public class ThreadGroupDemo extends Thread {
	
	public void run() {
		System.out.println("Running threads");
	}
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		
		ThreadGroupDemo t1= new ThreadGroupDemo();
	    t1.start();
		System.out.println(t1.getState());
		t1.stop();
		System.out.println(t1.getState());	
	}
	
}