package demo;

public class RunnableInterfaceThread implements Runnable{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RunnableInterfaceThread rit= new RunnableInterfaceThread();
		//injecting runnable object to thread class
		Thread t1= new Thread(rit);
		
		System.out.println(t1.isAlive());

		rit.run();
		t1.start();
		System.out.println(t1.isAlive());
	}
	@Override
	public void run() {

		System.out.println("Running thread program using Runnable interface");
	}
}