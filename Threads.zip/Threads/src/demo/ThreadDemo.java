package demo;

public class ThreadDemo extends Thread{
	
	public void run() {
		System.out.println("Runnning thread program!");
	}
	
	public static void main (String args[]) {
		
		ThreadDemo td= new ThreadDemo();
		td.start();	
	}
}