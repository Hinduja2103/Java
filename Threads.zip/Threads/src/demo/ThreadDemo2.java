package demo;

public class ThreadDemo2 extends Thread{
	
	public void run() {
		System.out.println("Runnning thread program!");
		System.out.println("Running Thread " + Thread.activeCount());
		for(int i=0;i<5;i++) {
			System.out.println(i);
		}
	}
	@SuppressWarnings("deprecation")
	public static void main (String args[]) {
		
		ThreadDemo2 t1= new ThreadDemo2();
		ThreadDemo2 t2= new ThreadDemo2();
		t2.setPriority(Thread.MAX_PRIORITY);
		t2.setName("Priority thread");
		System.out.println(t2.getPriority());
		System.out.println(t2.getName());
		System.out.println("hello" + t2.getState());
		t1.start();
		t2.start();
		System.out.println("hello" + t2.getState());
		t2.stop();
		System.out.println("T1" + t1.getState());
		System.out.println("T1" + t2.getState());
	}

}