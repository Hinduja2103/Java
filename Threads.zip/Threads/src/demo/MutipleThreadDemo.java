package demo;

public class MutipleThreadDemo extends Thread {

	public void run() {
		System.out.println("started running");
		for(int i=0;i<=10;i++) {
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		MutipleThreadDemo t1= new MutipleThreadDemo();
		MutipleThreadDemo t2= new MutipleThreadDemo();
		MutipleThreadDemo t3= new MutipleThreadDemo();
		t1.start();
		System.out.println("Thread1 :"+t1.isAlive());
		System.out.println("Thread2 "+t2.isAlive());
		System.out.println("Thread3 "+t3.isAlive());

		t1.setName("Thread First Java");
		System.out.println(t1.getName());
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.setName("Srikanth");
		System.out.println("Thread Name is :" + t2.getName());
		t2.start();
		t3.start();	
	}
}