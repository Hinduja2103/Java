package demo;

import demo.IOffice.Cabin;

public class NestedClass implements IOffice,Cabin {

	class InnerClass{
		void display() {
			System.out.println("Hello its thursday ");
		}
	}

	public static void main(String[] args) {
		
		NestedClass nc = new NestedClass();
		InnerClass ic =nc.new InnerClass();
		ic.display();
		IOffice i = new NestedClass();
		i.display();
		IOffice.Cabin cb=new NestedClass();
		cb.displaycabin();
		cb.helloInnerInterface();
	}

	@Override
	public void helloInnerInterface() {
		System.out.println("Hello I am inner interface");
	}

	@Override
	public void display() {
		System.out.println("Hello I am Super Interface");
	}

}
