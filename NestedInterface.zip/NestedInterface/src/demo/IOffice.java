package demo;

public interface IOffice {

	public interface Cabin{
		
		default void displaycabin() {
			System.out.println("I am cabin inside Office");
		}
		
		void helloInnerInterface();
		
		}

	void display();

}


